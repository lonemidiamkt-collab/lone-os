import Link from "next/link";
import clsx from "clsx";
import type { ComponentProps, ReactNode } from "react";

export function PageHeader({ eyebrow, title, children, actions }: {
  eyebrow?: string; title: string; children?: ReactNode; actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0">
        {eyebrow && <div className="text-[12px] font-semibold uppercase tracking-[0.14em] text-primary">{eyebrow}</div>}
        <h1 className="mt-1.5 text-[30px] font-bold leading-[1.15] tracking-[-0.02em] sm:text-[34px]">{title}</h1>
        {children && <div className="mt-2 max-w-[64ch] text-[15px] text-muted-foreground">{children}</div>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Card({ className, ...p }: ComponentProps<"div">) {
  return <div className={clsx("card", className)} {...p} />;
}

type Variant = "primary" | "ghost" | "danger" | "subtle";
const variants: Record<Variant, string> = {
  primary: "bg-primary text-primary-foreground shadow-brilho hover:brightness-110",
  ghost: "border border-input bg-card text-foreground hover:border-primary/40 hover:bg-accent",
  danger: "border border-lone-danger-border bg-card text-lone-danger hover:bg-lone-danger-bg",
  subtle: "bg-primary/10 text-primary hover:bg-primary/15",
};
const btn = "inline-flex min-h-10 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed";

export function Button({ variant = "primary", className, ...p }: ComponentProps<"button"> & { variant?: Variant }) {
  return <button className={clsx(btn, variants[variant], className)} {...p} />;
}

export function LinkButton({ variant = "primary", className, ...p }: ComponentProps<typeof Link> & { variant?: Variant }) {
  return <Link className={clsx(btn, variants[variant], className)} {...p} />;
}

export type Tone = "ok" | "warn" | "bad" | "idle" | "brand";
const tones: Record<Tone, string> = {
  ok: "bg-lone-success-bg text-lone-success", warn: "bg-lone-warning-bg text-lone-warning", bad: "bg-lone-danger-bg text-lone-danger",
  idle: "bg-muted text-muted-foreground", brand: "bg-primary/10 text-primary",
};
export function Pill({ tone = "idle", children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return <span className={clsx("inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold", tones[tone], className)}>{children}</span>;
}

export function Progress({ value, className, tone = "brand" }: { value: number; className?: string; tone?: "brand" | "ok" }) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div className={clsx("h-1.5 overflow-hidden rounded-full bg-muted", className)} role="progressbar" aria-valuenow={v} aria-valuemin={0} aria-valuemax={100}>
      <div className={clsx("h-full rounded-full", tone === "ok" ? "bg-lone-success" : "bg-primary")} style={{ width: `${v}%` }} />
    </div>
  );
}

export function Field({ label, hint, children, htmlFor }: { label: string; hint?: string; children: ReactNode; htmlFor?: string }) {
  return (
    <label htmlFor={htmlFor} className="flex flex-col gap-1.5 text-sm">
      <span className="font-semibold text-muted-foreground">{label}</span>
      {children}
      {hint && <span className="text-xs text-muted-foreground">{hint}</span>}
    </label>
  );
}

export function Stat({ label, value, hint, alert }: { label: string; value: ReactNode; hint?: ReactNode; alert?: boolean }) {
  return (
    <Card className="flex flex-col gap-2 p-5">
      <div className="text-[13px] font-medium text-muted-foreground">{label}</div>
      <div className={clsx("numero text-[34px] font-bold leading-none", alert && "text-lone-danger")}>{value}</div>
      {hint && <div className="text-[13px] text-muted-foreground">{hint}</div>}
    </Card>
  );
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <Card className="flex flex-col items-start gap-2 p-6">
      <h3 className="text-[17px] font-semibold">{title}</h3>
      {children && <div className="max-w-[60ch] text-sm text-muted-foreground">{children}</div>}
    </Card>
  );
}

export function Alert({ tone = "bad", children }: { tone?: "bad" | "ok" | "warn"; children: ReactNode }) {
  return <div className={clsx("rounded-lg px-3.5 py-2.5 text-sm", tones[tone])} role={tone === "bad" ? "alert" : "status"}>{children}</div>;
}

export function Avatar({ name, size = 32 }: { name: string; size?: number }) {
  const ini = name.split(/\s+/).filter(Boolean).map((s) => s[0]).slice(0, 2).join("").toUpperCase();
  return (
    <span className="grid flex-none place-items-center rounded-full bg-primary/10 font-bold text-primary"
      style={{ width: size, height: size, fontSize: size * 0.36 }} aria-hidden>{ini}</span>
  );
}
