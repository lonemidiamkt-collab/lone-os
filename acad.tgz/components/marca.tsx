import clsx from "clsx";

import { ASSINATURA_W, P_A, P_ACADEMY, P_CAPELO, P_LONE, SIMBOLO_H, SIMBOLO_W } from "./marca-paths";

// Marca da Lone Academy (v3, nov/2026): o A cortado pelo L, com o capelo; "LONE / ACADEMY" em Poppins.
// Geometria gerada por scripts/marca (marca-paths.ts). Cores da marca: exceção documentada do design system
// (logo), por isso os hex ficam aqui: azul #0D4AF5 (o mesmo da Lone Mídia), azul-noite #050A24, azul claro #6F8EFF.
type Tom = "auto" | "claro" | "negativo" | "azul";

// A (e o LONE), capelo e ACADEMY em cada fundo. "auto" = claro no tema claro, negativo no escuro.
const COR: Record<Tom, { a: string; capelo: string; academy: string }> = {
  auto: { a: "fill-[#050A24] dark:fill-white", capelo: "fill-[#0D4AF5]", academy: "fill-[#0D4AF5] dark:fill-[#6F8EFF]" },
  claro: { a: "fill-[#050A24]", capelo: "fill-[#0D4AF5]", academy: "fill-[#0D4AF5]" },
  negativo: { a: "fill-white", capelo: "fill-[#0D4AF5]", academy: "fill-[#6F8EFF]" },
  azul: { a: "fill-white", capelo: "fill-[#050A24]", academy: "fill-white" },
};

/** Símbolo (A + capelo). Dar largura e altura explícitas (proporção 0,86 : 1), ex.: `h-9 w-[31px]`. */
export function Simbolo({ className, tom = "auto", titulo = "Lone Academy" }: {
  className?: string; tom?: Tom; titulo?: string;
}) {
  const c = COR[tom];
  return (
    <svg viewBox={`0 0 ${SIMBOLO_W} ${SIMBOLO_H}`} className={className} role={titulo ? "img" : undefined}
      aria-label={titulo || undefined} aria-hidden={titulo ? undefined : true}>
      <path d={P_A} className={c.a} /><path d={P_CAPELO} className={c.capelo} />
    </svg>
  );
}

// Altura do símbolo em cada tamanho; a largura sai da proporção da assinatura (974,5 : 419,5).
const TAMANHO = { sm: 40, md: 52, lg: 84 } as const;

/** Assinatura horizontal: símbolo + LONE / ACADEMY (o mesmo desenho de public/brand/assinatura-horizontal.svg). */
export function Assinatura({ className, tamanho = "md", tom = "auto", sub }: {
  className?: string; tamanho?: keyof typeof TAMANHO; tom?: Tom; sub?: string;
}) {
  const c = COR[tom];
  const h = TAMANHO[tamanho];
  return (
    <span className={clsx("inline-flex flex-col items-start", className)}>
      <svg viewBox={`0 0 ${ASSINATURA_W} ${SIMBOLO_H}`} width={Math.round(h * ASSINATURA_W / SIMBOLO_H)} height={h}
        className="flex-none" role="img" aria-label="Lone Academy">
        <path d={P_A} className={c.a} /><path d={P_CAPELO} className={c.capelo} />
        <path d={P_LONE} className={c.a} /><path d={P_ACADEMY} className={c.academy} />
      </svg>
      {sub && <span className="mt-1.5 max-w-full truncate text-[11px] font-normal text-muted-foreground">{sub}</span>}
    </span>
  );
}

/** Selo "uma plataforma Lone Mídia" com o LM (logo da agência, PNG oficial). */
export function SeloLoneMidia({ className, escuro }: { className?: string; escuro?: boolean }) {
  return (
    <span className={clsx("inline-flex items-center gap-2 text-[12px]", className)}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={escuro ? "/brand/lone-midia-escuro.png" : "/brand/lone-midia-claro.png"} alt="" width={14} height={17}
        className={clsx("h-[17px] w-auto", !escuro && "dark:hidden")} />
      {!escuro && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src="/brand/lone-midia-escuro.png" alt="" width={14} height={17} className="hidden h-[17px] w-auto dark:block" />
      )}
      <span>uma plataforma <b className="font-semibold">Lone Mídia</b></span>
    </span>
  );
}
