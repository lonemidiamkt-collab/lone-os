"use client";
// Barra lateral da Lone Academy: sempre escura (.tema-escuro), nos dois temas, com a assinatura negativa da marca.
// Recolhe para um trilho só de ícones (76px) e lembra a escolha neste navegador.
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import clsx from "clsx";
import { PanelLeftClose, PanelLeftOpen, Search } from "lucide-react";
import { ativo, itemConfiguracoes, type GrupoMenu, type ItemMenu } from "@/lib/navegacao";
import { IconeMenu } from "./icone";
import { Foto } from "./foto";
import { Assinatura, SeloLoneMidia, Simbolo } from "@/components/marca";
import { ABRIR_BUSCA, abrir, gravarLocal, lerLocal } from "./eventos";
import type { Usuario } from "./tipos";

const CHAVE = "lone-academy-barra-recolhida";

export function Sidebar({ grupos, usuario }: { grupos: GrupoMenu[]; usuario: Usuario }) {
  const path = usePathname();
  const [recolhida, setRecolhida] = useState(false);
  useEffect(() => { setRecolhida(lerLocal(CHAVE) === "1"); }, []);
  const alternar = () => setRecolhida((v) => { gravarLocal(CHAVE, v ? "0" : "1"); return !v; });

  return (
    <aside
      className={clsx(
        "tema-escuro sticky top-0 hidden h-screen flex-none flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-[width] duration-200 ease-out lg:flex",
        recolhida ? "w-[76px]" : "w-[252px]",
      )}
      aria-label="Menu principal"
    >
      <Link href="/" aria-label="Lone Academy — início" className={clsx("flex min-h-[72px] items-center px-5 py-4 text-foreground", recolhida && "justify-center px-0")}>
        {recolhida ? <Simbolo tom="negativo" className="h-9 w-[31px]" /> : <Assinatura tamanho="md" tom="negativo" sub={usuario.empresa ?? "Lone Mídia"} />}
      </Link>
      {usuario.logoEmpresa && !recolhida && (
        // Marca do cliente só como logo (regra do produto), num selo claro para qualquer cor de logo.
        // eslint-disable-next-line @next/next/no-img-element
        <img src={usuario.logoEmpresa} alt={usuario.empresa ?? ""} className="mx-5 mb-3 h-9 max-w-[160px] self-start rounded-lg selo-logo-cliente object-contain px-2 py-1" />
      )}

      <div className={clsx("px-3 pb-2", recolhida && "px-2")}>
        <button type="button" onClick={() => abrir(ABRIR_BUSCA)} title="Buscar (⌘K)"
          className={clsx("flex w-full items-center gap-2 rounded-xl border border-border bg-background text-sm text-muted-foreground transition-colors hover:border-primary/30 hover:text-foreground",
            recolhida ? "h-10 justify-center" : "h-10 px-3")}>
          <Search size={15} aria-hidden />
          {!recolhida && <><span className="flex-1 text-left">Buscar</span><kbd>⌘K</kbd></>}
          {recolhida && <span className="sr-only">Buscar</span>}
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-2" aria-label="Seções">
        {grupos.map((g) => (
          <div key={g.rotulo} className="mb-4">
            {!recolhida && grupos.length > 1 && (
              <div className="px-3 pb-1.5 text-[12px] font-medium text-muted-foreground">{g.rotulo}</div>
            )}
            <ul className="flex flex-col gap-0.5">
              {g.itens.map((it) => <li key={it.href}><Item item={it} ativo={ativo(it, path)} recolhida={recolhida} /></li>)}
            </ul>
          </div>
        ))}
      </nav>

      <div className="flex flex-col gap-1 p-3">
        <Item item={itemConfiguracoes} ativo={ativo(itemConfiguracoes, path)} recolhida={recolhida} />
        <button type="button" onClick={alternar}
          className={clsx("flex h-10 items-center gap-3 rounded-xl px-3 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground",
            recolhida && "justify-center px-0")}
          aria-label={recolhida ? "Abrir barra lateral" : "Recolher barra lateral"} aria-expanded={!recolhida}>
          {recolhida ? <PanelLeftOpen size={17} strokeWidth={1.8} /> : <><PanelLeftClose size={17} strokeWidth={1.8} /><span>Recolher</span></>}
        </button>
        <Link href="/configuracoes" title={usuario.nome}
          className={clsx("mt-1 flex items-center gap-2.5 rounded-xl border border-border p-2 transition-colors hover:bg-sidebar-accent", recolhida && "justify-center border-transparent")}>
          <Foto nome={usuario.nome} url={usuario.avatar} size={34} />
          {!recolhida && (
            <span className="min-w-0 leading-tight">
              <span className="block truncate text-[13px] font-medium text-foreground">{usuario.nome}</span>
              <span className="block truncate text-[11px] text-muted-foreground">{usuario.cargo ?? usuario.papel}</span>
            </span>
          )}
        </Link>
        {!recolhida && <SeloLoneMidia escuro className="mt-2 px-2 text-muted-foreground" />}
      </div>
    </aside>
  );
}

function Item({ item, ativo, recolhida }: { item: ItemMenu; ativo: boolean; recolhida: boolean }) {
  return (
    <Link href={item.href} aria-current={ativo ? "page" : undefined} title={recolhida ? item.rotulo : undefined}
      className={clsx(
        "relative flex h-10 items-center gap-3 rounded-xl px-3 text-[14px] transition-colors",
        recolhida && "justify-center px-0",
        ativo ? "bg-primary/10 font-semibold text-primary" : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-foreground",
      )}>
      <IconeMenu nome={item.icone} className={ativo ? "text-primary" : undefined} />
      {recolhida ? <span className="sr-only">{item.rotulo}</span> : <span className="truncate">{item.rotulo}</span>}
    </Link>
  );
}
