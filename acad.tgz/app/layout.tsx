import type { Metadata, Viewport } from "next";
// Fonte empacotada pelo npm: o build não depende de acesso ao Google Fonts (VPS/Docker).
// Poppins = fonte da identidade Lone Academy (manual v3, nov/2026).
import "@fontsource/poppins/400.css";
import "@fontsource/poppins/500.css";
import "@fontsource/poppins/600.css";
import "@fontsource/poppins/700.css";
import "@fontsource/poppins/800.css";
import "./globals.css";
import { ThemeProvider } from "@/components/theme";

export const metadata: Metadata = {
  title: { default: "Lone Academy", template: "%s · Lone Academy" },
  description: "Treinamento do time dos clientes da Lone Mídia.",
  robots: { index: false, follow: false },
  applicationName: "Lone Academy",
  appleWebApp: { capable: true, title: "Lone Academy", statusBarStyle: "black-translucent" },
};

// Cor da barra do navegador no celular (exceção permitida a cor literal: metadado, não className).
export const viewport: Viewport = {
  themeColor: [{ media: "(prefers-color-scheme: light)", color: "#F5F7FB" }, { media: "(prefers-color-scheme: dark)", color: "#050A24" }],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body className="font-sans">
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
