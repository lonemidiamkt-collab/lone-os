import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import clsx from "clsx";
import { Check, Lock, PlayCircle, FileText, Award, ClipboardCheck } from "lucide-react";
import { exigir } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";
import { rpc, type Outline, type OutlineExam } from "@/lib/data";
import { cargaHoraria, dataCurta, dataHora, duracao } from "@/lib/format";
import { Card, LinkButton, Pill } from "@/components/ui";

export const metadata: Metadata = { title: "Curso" };

function ExamRow({ exam, final }: { exam: OutlineExam; final?: boolean }) {
  const s = exam.status;
  const texto =
    s === "passed" ? `Aprovado com ${exam.best_score}%` :
    s === "locked" ? (exam.locked_reason === "lessons_pending" ? "Termine as aulas para liberar" :
                      exam.locked_reason === "exams_pending" ? "Passe nas provas dos módulos para liberar" : "Abre depois do módulo anterior") :
    s === "cooldown" ? `Nova tentativa em ${dataHora(exam.retry_at)}` :
    s === "in_progress" ? "Prova em andamento" :
    `${exam.question_count} questões · nota mínima ${exam.passing_score}% · ${exam.attempts_left ?? 0} tentativa${exam.attempts_left === 1 ? "" : "s"}`;
  return (
    <div className={clsx("flex flex-wrap items-center gap-3 rounded-lg border px-3.5 py-3",
      s === "passed" ? "border-lone-success-border bg-lone-success-bg" : s === "available" || s === "in_progress" ? "border-primary/40 bg-primary/10" : "border-border bg-muted")}>
      <span className={clsx("grid h-8 w-8 flex-none place-items-center rounded-full",
        s === "passed" ? "bg-lone-success text-background" : s === "locked" || s === "cooldown" ? "bg-muted text-muted-foreground" : "bg-primary text-primary-foreground")}>
        {s === "passed" ? <Check size={16} /> : s === "locked" ? <Lock size={14} /> : <ClipboardCheck size={16} />}
      </span>
      <div className="min-w-0 flex-1">
        <div className="font-semibold">{exam.title}{final && <span className="ml-2 text-xs font-semibold uppercase tracking-wider text-primary">vale o certificado</span>}</div>
        <div className="text-sm text-muted-foreground">{texto}</div>
      </div>
      {(s === "available" || s === "in_progress") && <LinkButton href={`/prova/${exam.id}`}>{s === "in_progress" ? "Continuar prova" : "Fazer prova"}</LinkButton>}
      {s === "passed" && <Link href={`/prova/${exam.id}`} className="text-sm font-semibold text-lone-success">Ver resultado</Link>}
    </div>
  );
}

export default async function Curso({ params }: { params: Promise<{ slug: string }> }) {
  await exigir(["learner", "company_manager"]);
  const { slug } = await params;
  const supabase = await supabaseServer();
  const { data: c } = await supabase.from("courses").select("id").eq("slug", slug).maybeSingle();
  if (!c) notFound();

  await rpc("start_course", { p_course: c.id });
  const o = await rpc<Outline>("course_outline", { p_course: c.id });
  const pct = o.enrollment?.progress_pct ?? 0;

  // primeira aula ainda não concluída em módulo aberto = "continuar"
  const proxima = o.modules.filter((m) => m.unlocked).flatMap((m) => m.lessons).find((l) => !l.completed && (l.kind === "text" || l.video_ready));

  return (
    <>
      <section className="bloco-profundo animar-entrada mb-6 grid gap-6 overflow-hidden rounded-3xl p-6 sm:p-8 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
        <div className="flex min-w-0 flex-col gap-3">
          <span className="text-[12px] font-bold uppercase tracking-[0.14em] text-lone-brand-soft">Curso</span>
          <h1 className="text-[28px] font-extrabold leading-tight tracking-[-0.02em] sm:text-[34px]">{o.course.title}</h1>
          {(o.course.description ?? o.course.summary) && <p className="max-w-[62ch] text-[15px] leading-relaxed text-profundo-muted">{o.course.description ?? o.course.summary}</p>}
          <div className="mt-1 flex flex-wrap gap-2 text-[13px]">
            <span className="rounded-full bg-profundo-linha px-3 py-1">{cargaHoraria(o.course.workload_minutes)}</span>
            <span className="rounded-full bg-profundo-linha px-3 py-1">{o.modules.length} módulo{o.modules.length === 1 ? "" : "s"}</span>
            {o.assignment?.due_date && <span className="rounded-full bg-primary px-3 py-1 font-semibold text-primary-foreground">Prazo {dataCurta(o.assignment.due_date)}</span>}
            {o.course.sequential && <span className="rounded-full bg-profundo-linha px-3 py-1">Módulos em sequência</span>}
          </div>
          <div className="mt-3">
            {o.certificate_code
              ? <LinkButton href="/certificados"><Award size={16} /> Ver certificado</LinkButton>
              : proxima ? <LinkButton href={`/aula/${proxima.id}`} className="!h-12 !rounded-2xl !px-6 text-[15px]">{pct > 0 ? "Continuar de onde parei" : "Começar o curso"}</LinkButton> : null}
          </div>
        </div>
        <div className="flex items-center gap-4 md:flex-col md:gap-2">
          <svg width="128" height="128" viewBox="0 0 128 128" role="img" aria-label={`${pct}% concluído`} className="flex-none">
            <circle cx="64" cy="64" r="54" fill="none" stroke="var(--profundo-linha)" strokeWidth="10" />
            <circle cx="64" cy="64" r="54" fill="none" stroke="var(--primary)" strokeWidth="10" strokeLinecap="round"
              strokeDasharray={`${(Math.max(pct, 1) / 100) * 339.3} 339.3`} transform="rotate(-90 64 64)" />
            <text x="64" y="70" textAnchor="middle" fontSize="28" fontWeight="800" fill="currentColor">{pct}%</text>
          </svg>
          <span className="text-[13px] text-profundo-muted">{o.enrollment?.completed_at ? "Curso concluído" : "do curso feito"}</span>
        </div>
      </section>

      <div className="flex flex-col gap-4">
        {o.modules.map((m, i) => (
          <Card key={m.id} className={clsx("p-5", !m.unlocked && "opacity-75")}>
            <div className="mb-3 flex flex-wrap items-start gap-2">
              <span className="font-display text-sm font-semibold text-muted-foreground">Módulo {i + 1}</span>
              {m.competency && <Pill tone="brand">{m.competency}</Pill>}
              {!m.unlocked && <Pill><Lock size={12} /> Trancado</Pill>}
            </div>
            <h2 className="text-lg font-semibold">{m.title}</h2>
            {m.description && <p className="mt-1 text-sm text-muted-foreground">{m.description}</p>}

            <ul className="mt-4 flex flex-col">
              {m.lessons.map((l) => {
                const pode = m.unlocked && (l.kind === "text" || l.video_ready);
                const conteudo = (
                  <div className="flex items-center gap-3 py-2.5">
                    <span className={clsx("grid h-6 w-6 flex-none place-items-center rounded-full border text-[11px]",
                      l.completed ? "border-lone-success bg-lone-success text-background" : "border-border text-muted-foreground")}>
                      {l.completed ? <Check size={13} /> : l.kind === "video" ? <PlayCircle size={13} /> : <FileText size={12} />}
                    </span>
                    <span className={clsx("min-w-0 flex-1", pode && "group-hover:text-primary")}>{l.title}
                      {!l.required && <span className="ml-2 text-xs text-muted-foreground">(extra)</span>}</span>
                    <span className="text-xs text-muted-foreground tabular-nums">
                      {l.quiz_pending ? <span className="font-semibold text-primary">faltam as perguntas</span>
                        : l.kind === "video" ? (l.video_ready ? duracao(l.duration_seconds) : "em breve") : "leitura"}
                    </span>
                  </div>
                );
                return <li key={l.id} className="border-t border-border first:border-t-0">
                  {pode ? <Link href={`/aula/${l.id}`} className="group block">{conteudo}</Link> : conteudo}
                </li>;
              })}
            </ul>
            {m.exam && <div className="mt-3"><ExamRow exam={m.exam} /></div>}
          </Card>
        ))}

        {o.final_exam && (
          <Card className="p-5">
            <h2 className="mb-3 text-lg font-semibold">Avaliação final</h2>
            <ExamRow exam={o.final_exam} final />
          </Card>
        )}
      </div>
    </>
  );
}
