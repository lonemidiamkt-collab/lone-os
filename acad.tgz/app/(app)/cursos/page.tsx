import type { Metadata } from "next";
import Link from "next/link";
import clsx from "clsx";
import { CalendarClock, Flame, GraduationCap, Play, Search } from "lucide-react";
import { exigir } from "@/lib/auth";
import { cursosDoAluno, meusNumeros, type CursoCard } from "@/lib/data";
import { continuarDeOndeParou, minhaSemana } from "@/lib/inicio";
import { calcularAdocao, calcularSkill, proximoNivel } from "@/lib/score";
import { cargaHoraria, dataCurta, duracao } from "@/lib/format";
import { Card, Empty, Pill, Progress } from "@/components/ui";
import { NivelPill, SkillRing } from "@/components/score";

export const metadata: Metadata = { title: "Início" };

function hojeBR() { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Sao_Paulo" }); }
function saudacao() {
  const h = Number(new Date().toLocaleString("en-US", { hour: "numeric", hour12: false, timeZone: "America/Sao_Paulo" }));
  return h < 12 ? "Bom dia" : h < 18 ? "Boa tarde" : "Boa noite";
}
const mmss = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

function CardCurso({ c }: { c: CursoCard }) {
  const atrasado = c.due_date && !c.completed_at && c.due_date < hojeBR();
  return (
    <Link href={`/cursos/${c.slug}`} className="group animar-entrada">
      <Card className="flex h-full flex-col overflow-hidden transition duration-200 group-hover:-translate-y-0.5 group-hover:shadow-pop">
        {c.cover_url
          // eslint-disable-next-line @next/next/no-img-element
          ? <img src={c.cover_url} alt="" className="aspect-[16/7] w-full object-cover" />
          : <div className="bloco-profundo grid aspect-[16/7] w-full place-items-center"><GraduationCap size={30} strokeWidth={1.5} aria-hidden className="text-profundo-muted" /></div>}
        <div className="flex flex-1 flex-col gap-3 p-5">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] font-bold uppercase tracking-[0.12em] text-primary">{c.category ?? "Curso"}</span>
            {c.completed_at ? <Pill tone="ok">Concluído</Pill> : atrasado ? <Pill tone="bad">Atrasado</Pill>
              : c.due_date ? <Pill tone="brand">Até {dataCurta(c.due_date)}</Pill> : null}
          </div>
          <h3 className="text-[17px] font-bold leading-snug tracking-[-0.02em]">{c.title}</h3>
          {c.summary && <p className="line-clamp-2 text-sm text-muted-foreground">{c.summary}</p>}
          <div className="mt-auto pt-1">
            <div className="mb-1.5 flex justify-between text-xs text-muted-foreground">
              <span>{c.progress_pct == null ? "Não iniciado" : `${c.progress_pct}% concluído`}</span>
              <span>{cargaHoraria(c.workload_minutes)}</span>
            </div>
            <Progress value={c.progress_pct ?? 0} tone={c.completed_at ? "ok" : "brand"} />
          </div>
        </div>
      </Card>
    </Link>
  );
}

export default async function Inicio({ searchParams }: { searchParams: Promise<{ q?: string; cat?: string }> }) {
  const { profile, company } = await exigir(["learner", "company_manager"]);
  const { q = "", cat = "" } = await searchParams;
  const [todos, m, semana] = await Promise.all([cursosDoAluno(profile.id), meusNumeros(), minhaSemana(profile.id)]);
  const continuar = await continuarDeOndeParou(profile.id, todos);
  const skill = m ? calcularSkill(m) : null;
  const adocao = m ? calcularAdocao(m) : null;
  const prox = skill?.valor != null ? proximoNivel(skill.valor) : null;
  const prazo = todos.filter((c) => c.due_date && !c.completed_at).sort((a, b) => a.due_date!.localeCompare(b.due_date!))[0];

  const categorias = [...new Set(todos.map((c) => c.category).filter((x): x is string => !!x))].sort();
  const norm = (t: string) => t.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const filtrando = !!(q.trim() || cat);
  const cursos = todos.filter((c) => (!cat || c.category === cat)
    && (!q.trim() || norm(`${c.title} ${c.summary ?? ""} ${c.category ?? ""}`).includes(norm(q.trim()))));
  const atribuidos = cursos.filter((c) => c.assigned && !c.completed_at);
  const andamento = cursos.filter((c) => !c.assigned && c.progress_pct != null && !c.completed_at);
  const concluidos = cursos.filter((c) => c.completed_at);
  const disponiveis = cursos.filter((c) => !c.assigned && c.progress_pct == null);
  const nome = profile.full_name.split(" ")[0];

  return (
    <>
      <header className="mb-6 flex flex-col gap-1.5">
        <div className="flex flex-wrap items-center gap-3">
          <h1 className="text-[30px] font-bold leading-tight tracking-[-0.02em] sm:text-[34px]">
            {continuar && (continuar.acao.startsWith("Continuar") || continuar.progressoCurso > 0) ? `Bora continuar, ${nome}?` : `${saudacao()}, ${nome}`}
          </h1>
          {semana.sequencia >= 2 && (
            <span className="inline-flex items-center gap-1 rounded-full bg-lone-warning-bg px-3 py-1 text-[13px] font-bold text-lone-warning" title="Dias seguidos estudando">
              <Flame size={14} aria-hidden /> {semana.sequencia} dias seguidos
            </span>
          )}
        </div>
        <p className="text-[15px] text-muted-foreground">
          {continuar ? "Aulas curtas, direto ao ponto. Cada módulo termina com uma prova rápida." : "Aulas curtas sobre o que você faz no dia a dia."}
        </p>
      </header>

      {continuar && (
        <section className="bloco-profundo animar-entrada mb-5 grid gap-6 overflow-hidden rounded-3xl p-6 sm:p-7 lg:grid-cols-[minmax(0,1fr)_340px]">
          <div className="flex flex-col justify-between gap-6">
            <div className="flex flex-col gap-2.5">
              <span className="self-start rounded-full bg-profundo-linha px-3 py-1 text-xs font-semibold">
                {continuar.tipo === "aula" ? "Continuar de onde parou" : "Próximo curso"}
              </span>
              <span className="text-sm text-profundo-muted">{continuar.curso}{continuar.modulo ? ` · ${continuar.modulo}` : ""}</span>
              <h2 className="text-[26px] font-bold leading-tight tracking-[-0.025em] sm:text-[30px]">{continuar.titulo}</h2>
            </div>
            <div className="flex flex-col gap-2.5">
              <div className="flex justify-between text-[13px] text-profundo-muted">
                <span>Curso {continuar.progressoCurso}% concluído</span>
                {continuar.duracao ? <span>{duracao(continuar.duracao)} de vídeo</span> : null}
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-profundo-linha">
                <div className="h-full rounded-full bg-primary" style={{ width: `${Math.max(3, continuar.progressoCurso)}%` }} />
              </div>
              <Link href={continuar.href}
                className="mt-2 inline-flex h-12 items-center gap-2.5 self-start rounded-2xl bg-primary px-6 text-[15px] font-semibold text-primary-foreground shadow-brilho transition hover:brightness-110 active:scale-[0.98]">
                <Play size={16} fill="currentColor" aria-hidden /> {continuar.acao}
              </Link>
            </div>
          </div>
          <Link href={continuar.href} aria-hidden tabIndex={-1}
            className="relative hidden aspect-video items-center justify-center rounded-2xl border border-profundo-linha bg-profundo-linha lg:flex">
            <span className="grid h-16 w-16 place-items-center rounded-full bg-profundo-linha backdrop-blur"><Play size={24} fill="currentColor" /></span>
            {continuar.posicao && continuar.duracao
              ? <span className="numero absolute bottom-3 right-3 text-xs">{mmss(continuar.posicao)} / {mmss(continuar.duracao)}</span> : null}
          </Link>
        </section>
      )}

      {skill && adocao && (
        <div className="mb-10 grid gap-4 md:grid-cols-2">
          <Link href="/meu-score" className="group">
            <Card className="flex h-full items-center gap-5 p-5 transition group-hover:shadow-pop">
              <SkillRing valor={skill.valor} nivel={skill.nivel} size={92} />
              <div className="min-w-0">
                <div className="text-[13px] text-muted-foreground">Seu Skill Score</div>
                <div className="mt-1"><NivelPill nivel={skill.nivel} provisorio={skill.valor != null && skill.provisorio} /></div>
                <div className="mt-1.5 text-[13px] text-muted-foreground">
                  {skill.valor == null ? "Aparece depois da primeira prova." : prox ? `Faltam ${prox.faltam} pontos para ${prox.nivel}` : "Nível máximo. Mandou bem."}
                </div>
              </div>
            </Card>
          </Link>
          <Card className="flex flex-col gap-2 p-5">
            <span className="text-[13px] text-muted-foreground">Próximo prazo</span>
            {prazo ? (
              <>
                <span className="text-[17px] font-bold leading-snug tracking-[-0.02em]">{prazo.title}</span>
                <span className="text-[13px] text-muted-foreground">{prazo.progress_pct ?? 0}% feito</span>
                <span className={clsx("mt-auto inline-flex items-center gap-1.5 pt-2 text-[13px] font-semibold", prazo.due_date! < hojeBR() ? "text-lone-danger" : "text-lone-warning")}>
                  <CalendarClock size={15} aria-hidden /> {prazo.due_date! < hojeBR() ? "Venceu em" : "Até"} {dataCurta(prazo.due_date)}
                </span>
              </>
            ) : <span className="text-[15px] font-medium">Nenhum prazo em aberto. Siga no seu ritmo.</span>}
          </Card>
        </div>
      )}

      {todos.length > 3 && (
        <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
          <form role="search" className="relative w-full max-w-sm">
            <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <input name="q" defaultValue={q} placeholder="Buscar curso" aria-label="Buscar curso" className="!pl-10" />
            {cat && <input type="hidden" name="cat" value={cat} />}
          </form>
          {categorias.length > 0 && (
            <nav aria-label="Categorias" className="flex flex-wrap gap-2">
              {["", ...categorias].map((k) => (
                <Link key={k || "todas"} href={`/cursos?${new URLSearchParams({ ...(q ? { q } : {}), ...(k ? { cat: k } : {}) })}`}
                  aria-current={cat === k ? "true" : undefined}
                  className={clsx("rounded-full border px-3.5 py-1.5 text-sm", cat === k ? "border-primary bg-primary/10 font-semibold text-primary" : "border-border text-muted-foreground hover:bg-accent")}>
                  {k || "Todas"}
                </Link>
              ))}
            </nav>
          )}
        </div>
      )}

      {todos.length === 0 && (company && company.status !== "active"
        ? <Empty title="Cursos bloqueados por enquanto">O acesso da empresa está pausado. Seus cursos, notas e certificados continuam guardados.</Empty>
        : <Empty title="Nenhum curso liberado ainda">A Lone libera os cursos para a sua empresa. Assim que tiver um, ele aparece aqui.</Empty>)}
      {filtrando && cursos.length === 0 && <Empty title="Nenhum curso encontrado"><Link href="/cursos" className="font-semibold text-primary">Limpar busca</Link></Empty>}

      {([["Atribuídos pelo seu gestor", atribuidos], ["Em andamento", andamento], ["Disponíveis para você", disponiveis], ["Concluídos", concluidos]] as [string, CursoCard[]][])
        .filter(([, l]) => l.length > 0)
        .map(([titulo, lista]) => (
          <section key={titulo} className="mb-10">
            <h2 className="mb-4 text-[19px] font-bold tracking-[-0.02em]">{titulo}</h2>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {lista.map((c) => <CardCurso key={c.id} c={c} />)}
            </div>
          </section>
        ))}
    </>
  );
}
