import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { sessaoAtual, inicioDoPapel } from "@/lib/auth";
import { supabaseServer } from "@/lib/supabase/server";
import Link from "next/link";
import { SubmitButton } from "@/components/client";

export const metadata: Metadata = { title: "Privacidade" };

async function aceitar() {
  "use server";
  const supabase = await supabaseServer();
  const { error } = await supabase.rpc("accept_privacy");
  if (error) throw new Error("Não consegui registrar. Tente de novo.");
  const s = await sessaoAtual();
  redirect(inicioDoPapel(s?.profile.role ?? "learner"));
}

// Aviso de privacidade (LGPD) mostrado no primeiro acesso. Texto revisável pelo jurídico da Lone.
export default async function Privacidade() {
  const s = await sessaoAtual();
  if (!s) redirect("/entrar");
  const contato = process.env.NEXT_PUBLIC_PRIVACY_CONTACT || "o gestor da sua loja ou a Lone Mídia";
  const empresa = s.company?.name ?? "a empresa onde você trabalha";
  const itens: [string, string][] = [
    ["Quem cuida dos dados", `A Lone Mídia opera a Lone Academy para ${empresa}, que contratou os treinamentos.`],
    ["O que guardamos", "Seu nome, cargo e login; as aulas que você fez; suas respostas e notas nas provas; certificados; dias e horários de acesso."],
    ["Para quê", "Registrar seu treinamento, emitir seus certificados e mostrar ao gestor como está o desenvolvimento do time."],
    ["Quem vê", "Você vê tudo. O gestor da sua empresa vê progresso, notas, competências e score, mas não as suas respostas uma a uma. A equipe da Lone vê para dar suporte e acompanhar o cliente."],
    ["O que não fazemos", "Não lemos suas conversas de WhatsApp. O score é uma referência de treinamento; não é usado sozinho para decidir contratação, promoção ou demissão."],
    ["Certificado", "Quem tiver o código do certificado consegue confirmar seu nome, o curso, a empresa e a data na página de verificação."],
    ["Se você sair da empresa", "O gestor desativa seu acesso. O histórico fica guardado para que os certificados emitidos continuem verificáveis."],
    ["Seus direitos", `Você pode pedir acesso, correção ou exclusão dos seus dados falando com ${contato}.`],
  ];
  return (
    <>
      <h1 className="text-[30px] font-extrabold leading-tight tracking-[-0.02em]">Antes de começar</h1>
      <p className="mb-5 mt-2 text-[15px] text-muted-foreground">Como seus dados são usados na Lone Academy. Leva 1 minuto.</p>
      <dl className="card mb-5 flex max-h-[52vh] flex-col gap-3.5 overflow-y-auto p-5 text-sm">
        {itens.map(([t, d]) => <div key={t}><dt className="font-semibold">{t}</dt><dd className="text-muted-foreground">{d}</dd></div>)}
      </dl>
      {s.profile.privacy_accepted_at
        ? <Link href="/configuracoes#conta" className="block w-full rounded-lg bg-primary py-2.5 text-center text-sm font-semibold text-primary-foreground hover:opacity-90">Voltar</Link>
        : <form action={aceitar}><SubmitButton pendingText="Registrando…" className="!h-12 w-full !rounded-2xl text-[15px]">Li e entendi, continuar</SubmitButton></form>}
    </>
  );
}
