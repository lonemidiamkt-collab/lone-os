import { LineChart, Layers, Zap } from "lucide-react";
import { Assinatura, SeloLoneMidia, Simbolo } from "@/components/marca";

// Entrada, convite (cadastro), troca de senha e privacidade: painel da marca à esquerda (no computador)
// e o formulário à direita. No celular fica só o formulário, com a assinatura no topo.
const PILARES = [
  { I: LineChart, t: "Evolução", d: "Seu score mostra o que você já domina e o que falta." },
  { I: Layers, t: "Aprendizado", d: "Aulas curtas, direto do dia a dia da loja." },
  { I: Zap, t: "Performance", d: "Mais atendimento bem feito, mais venda fechada." },
];

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)]">
      <aside className="tema-escuro bloco-profundo relative hidden overflow-hidden lg:flex lg:flex-col lg:justify-between lg:p-12 xl:p-16">
        {/* símbolo gigante ao fundo: textura da marca, decorativo */}
        <Simbolo tom="negativo" titulo="" className="pointer-events-none absolute -bottom-28 -right-16 h-[600px] w-[514px] opacity-[0.06]" />
        <Assinatura tamanho="lg" tom="negativo" />
        <div className="relative max-w-[460px]">
          <p className="text-[40px] font-extrabold leading-[1.08] tracking-[-0.025em] xl:text-[46px]">
            Treinamento curto.<br /><span className="text-lone-brand-soft">Resultado no balcão.</span>
          </p>
          <p className="mt-4 text-[16px] leading-relaxed text-profundo-muted">
            Plataforma de desenvolvimento, capacitação e performance para o time dos clientes da Lone Mídia.
          </p>
          <ul className="mt-10 flex flex-col gap-5">
            {PILARES.map(({ I, t, d }) => (
              <li key={t} className="flex items-start gap-4">
                <span className="grid h-11 w-11 flex-none place-items-center rounded-xl border border-profundo-linha bg-profundo-linha text-lone-brand-soft"><I size={19} aria-hidden /></span>
                <span><b className="block text-[15px] font-bold">{t}</b><span className="text-sm text-profundo-muted">{d}</span></span>
              </li>
            ))}
          </ul>
        </div>
        <SeloLoneMidia escuro className="relative text-profundo-muted" />
      </aside>

      <main className="flex min-h-screen flex-col px-5 py-8 sm:px-10">
        <div className="lg:hidden"><Assinatura tamanho="md" /></div>
        <div className="mx-auto flex w-full max-w-[400px] flex-1 flex-col justify-center py-10 animar-entrada">{children}</div>
        <div className="flex justify-center lg:hidden"><SeloLoneMidia className="text-muted-foreground" /></div>
      </main>
    </div>
  );
}
