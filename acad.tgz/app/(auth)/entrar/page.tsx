import type { Metadata } from "next";
import { EntrarForm } from "./form";

export const metadata: Metadata = { title: "Entrar" };

export default async function Entrar({ searchParams }: { searchParams: Promise<{ next?: string; erro?: string }> }) {
  const sp = await searchParams;
  return (
    <>
      <h1 className="text-[30px] font-extrabold leading-tight tracking-[-0.02em]">Que bom te ver</h1>
      <p className="mb-8 mt-2 text-[15px] text-muted-foreground">Entre com o login que o gestor da sua loja passou para você.</p>
      <EntrarForm next={sp.next} aviso={sp.erro === "inativo" ? "Este acesso está desativado. Fale com o gestor da sua loja." : undefined} />
    </>
  );
}
