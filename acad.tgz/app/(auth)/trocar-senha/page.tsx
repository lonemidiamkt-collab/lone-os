"use client";
import { useActionState } from "react";
import { trocarSenha } from "./actions";
import { SubmitButton } from "@/components/client";
import { NovaSenha } from "@/components/auth-campos";

export default function TrocarSenha() {
  const [state, action] = useActionState(trocarSenha, undefined);
  return (
    <>
      <h1 className="text-[30px] font-extrabold leading-tight tracking-[-0.02em]">Crie sua senha</h1>
      <p className="mb-7 mt-2 text-[15px] text-muted-foreground">A senha que você recebeu era provisória. Escolha uma que só você saiba.</p>
      <form action={action} className="flex flex-col gap-5">
        {state?.erro && <div role="alert" className="rounded-lg bg-lone-danger-bg px-3 py-2 text-sm text-lone-danger">{state.erro}</div>}
        <NovaSenha rotulo="Nova senha" />
        <SubmitButton pendingText="Salvando…" className="mt-1 !h-12 !rounded-2xl text-[15px]">Salvar e continuar</SubmitButton>
      </form>
    </>
  );
}
