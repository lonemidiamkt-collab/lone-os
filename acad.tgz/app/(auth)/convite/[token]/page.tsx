import type { Metadata } from "next";
import Link from "next/link";
import { conviteDoToken } from "@/lib/accounts";
import { normalizarUsuario } from "@/lib/auth";
import { ConviteForm } from "./form";

export const metadata: Metadata = { title: "Convite" };

export default async function Convite({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const convite = await conviteDoToken(token);
  if ("erro" in convite) {
    return (
      <>
        <h1 className="text-[28px] font-extrabold tracking-[-0.02em]">Convite indisponível</h1>
        <p className="mb-6 mt-2 text-[15px] text-muted-foreground">{convite.erro}</p>
        <Link href="/entrar" className="inline-flex h-12 items-center justify-center rounded-2xl bg-primary px-6 text-[15px] font-semibold text-primary-foreground shadow-brilho">Ir para o login</Link>
      </>
    );
  }
  const [primeiro, ...resto] = convite.full_name.trim().split(/\s+/);
  const sugestao = normalizarUsuario([primeiro, resto.at(-1)].filter(Boolean).join("."));
  return (
    <>
      <span className="mb-4 inline-flex items-center gap-2 self-start rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
        <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-hidden /> Convite da {convite.company_name}
      </span>
      <h1 className="text-[30px] font-extrabold leading-tight tracking-[-0.02em]">Oi, {primeiro}! Bora começar?</h1>
      <p className="mb-6 mt-2 text-[15px] text-muted-foreground">
        {convite.role === "company_manager"
          ? <>A Lone Mídia liberou a Lone Academy para a {convite.company_name}. Crie sua senha e, no painel, convide o time.</>
          : <>A {convite.company_name} liberou os treinamentos da Lone Academy para você. Leva 1 minuto para criar o acesso.</>}
      </p>
      <ol className="mb-7 grid grid-cols-3 gap-2 text-[12px]" aria-label="Passos">
        {(convite.role === "company_manager" ? ["Criar acesso", "Aviso de privacidade", "Convidar o time"] : ["Criar acesso", "Aviso de privacidade", "Primeira aula"]).map((p, i) => (
          <li key={p} className="flex flex-col gap-1.5">
            <span className={i === 0 ? "h-1 rounded-full bg-primary" : "h-1 rounded-full bg-muted"} aria-hidden />
            <span className={i === 0 ? "font-semibold text-foreground" : "text-muted-foreground"}>{i + 1}. {p}</span>
          </li>
        ))}
      </ol>
      <ConviteForm token={token} sugestao={sugestao} email={convite.email} />
    </>
  );
}
