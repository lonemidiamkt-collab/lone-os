// Rasteriza os SVGs da marca em PNG de alta resolução (fundo transparente).
const { chromium } = require("playwright"); const fs = require("fs");
const jobs = [
  ["simbolo", [1024, 512]], ["simbolo-negativo", [1024]], ["simbolo-azul", [1024]], ["simbolo-mono-preto", [1024]], ["simbolo-mono-branco", [1024]],
  ["assinatura-horizontal", [2400]], ["assinatura-horizontal-negativa", [2400, 210]], ["assinatura-horizontal-azul", [2400]],
  ["assinatura-vertical", [1600]], ["assinatura-vertical-negativa", [1600]],
  ["icone-app", [1024, 512, 192, 180]], ["favicon", [64, 48, 32, 16]], ["icone-app-azul", [1024]],
];
(async () => {
  const b = await chromium.launch(); fs.mkdirSync("png", { recursive: true });
  for (const [n, ws] of jobs) {
    const svg = fs.readFileSync(`svg/${n}.svg`, "utf8");
    const [, , , vw, vh] = svg.match(/viewBox="([-\d.]+) ([-\d.]+) ([\d.]+) ([\d.]+)"/);
    for (const w of ws) {
      const h = Math.round(w * vh / vw);
      const p = await b.newPage({ viewport: { width: w, height: h } });
      await p.setContent(`<html><body style="margin:0;background:transparent">${svg.replace("<svg ", `<svg width="${w}" height="${h}" `)}</body></html>`);
      await p.screenshot({ path: `png/${n}-${w}.png`, omitBackground: true, clip: { x: 0, y: 0, width: w, height: h } });
      await p.close();
    }
  }
  await b.close(); console.log("png ok");
})();
