# Gera o símbolo da Lone Academy (v3, nov/2026): um A sólido cortado por dois vãos que desenham o L, com o capelo.
# Fonte da verdade da geometria: components/marca.tsx e lib/pdf-marca.tsx copiam os paths daqui (P_*).
#
# Unidade "x" = largura do vão (35). Regras do desenho (manual da marca):
# - os dois vãos (vertical e horizontal) têm 1x; as três pernas do A têm a mesma inclinação (dx/dy = 0,4028);
# - topo da perna esquerda = 0,5x (antes era uma lasca de 0,2x que sumia em ícone pequeno);
# - capelo centralizado no topo do A, a 0,8x acima dele; fita com 0,3x.
X = 35
INC = 131.5 / 326.5
TOPO, BASE, BARRA = 93.0, 419.5, 301.0          # y do topo do A, da base e do início do vão horizontal
ESQ_TOPO, CORTE, DIR_TOPO = 131.5, 149.0, 227.5  # topo da perna esquerda, borda esquerda do vão vertical, topo direito
W, H = 359.0, 419.5                              # caixa do símbolo (0,0 = canto superior esquerdo)

def f(v): return f"{v:.2f}".rstrip("0").rstrip(".")
def dir_(y): return DIR_TOPO + INC * (y - TOPO)
def path(*pts): return "M" + " L".join(f"{f(x)},{f(y)}" for x, y in pts) + " Z"

D1 = CORTE + X
P_A = " ".join([
    path((ESQ_TOPO, TOPO), (CORTE, TOPO), (CORTE, BASE), (ESQ_TOPO - INC * (BASE - TOPO), BASE)),
    path((D1, TOPO), (DIR_TOPO, TOPO), (dir_(BARRA), BARRA), (D1, BARRA)),
    path((D1, BARRA + X), (dir_(BARRA + X), BARRA + X), (dir_(BASE), BASE), (D1, BASE)),
])
CX = (ESQ_TOPO + DIR_TOPO) / 2
P_CAPELO = " ".join([
    path((CX - 98, 32), (CX, 0), (CX + 98, 32), (CX, 64)),
    path((CX + 89, 32), (CX + 99, 32), (CX + 99, 124), (CX + 89, 114)),
])

# Paleta (manual v3): azul da Lone (o mesmo da Lone Mídia), azul-noite, azul claro.
AZUL, NOITE, CLARO, BRANCO = "#0D4AF5", "#050A24", "#6F8EFF", "#FFFFFF"

def g(cor_a, cor_cap, tx=0.0, ty=0.0, k=1.0):
    t = f' transform="translate({f(tx)},{f(ty)}) scale({f(k)})"' if (tx or ty or k != 1) else ""
    return f'<g{t}><path d="{P_A}" fill="{cor_a}"/><path d="{P_CAPELO}" fill="{cor_cap}"/></g>'

PAD = 24
VB = f"{-PAD} {-PAD} {f(W + 2*PAD)} {f(H + 2*PAD)}"
def svg(cor_a, cor_cap):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{VB}" role="img" aria-label="Lone Academy">{g(cor_a, cor_cap)}</svg>'

VERSOES = {
    "simbolo": svg(NOITE, AZUL),            # principal, fundo claro
    "simbolo-negativo": svg(BRANCO, AZUL),  # fundo escuro
    "simbolo-azul": svg(BRANCO, NOITE),     # sobre o azul da marca
    "simbolo-mono-preto": svg(NOITE, NOITE),
    "simbolo-mono-branco": svg(BRANCO, BRANCO),
}

def icone(fundo="noite", k=1.78, raio=230):
    """Ícone de app: quadrado 1024 arredondado com o símbolo centralizado."""
    if fundo == "azul":
        defs, bg, cor_a, cor_cap = "", f'<rect width="1024" height="1024" rx="{raio}" fill="{AZUL}"/>', BRANCO, NOITE
    else:
        defs = ('<defs><radialGradient id="ic-luz" cx="380" cy="300" r="760" gradientUnits="userSpaceOnUse">'
                '<stop offset="0" stop-color="#12279A"/><stop offset=".55" stop-color="#0A1650"/>'
                f'<stop offset="1" stop-color="{NOITE}"/></radialGradient></defs>')
        bg, cor_a, cor_cap = f'<rect width="1024" height="1024" rx="{raio}" fill="url(#ic-luz)"/>', BRANCO, AZUL
    tx, ty = (1024 - W * k) / 2, (1024 - H * k) / 2
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024">{defs}{bg}{g(cor_a, cor_cap, tx, ty, k)}</svg>'

VERSOES["icone-app"] = icone()
VERSOES["icone-app-azul"] = icone("azul")
VERSOES["favicon"] = icone(k=2.12, raio=200)    # símbolo maior: em 16–32 px cada pixel conta

if __name__ == "__main__":
    import sys, os
    out = sys.argv[1]; os.makedirs(out, exist_ok=True)
    for k, v in VERSOES.items():
        open(f"{out}/{k}.svg", "w").write(v)
    print("A:", P_A); print("CAPELO:", P_CAPELO)
