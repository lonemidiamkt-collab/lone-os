# Assinaturas da Lone Academy (v3) com o texto em curvas (não depende da fonte instalada).
# "LONE" Poppins Bold + "ACADEMY" Poppins Medium espaçado, os dois com a mesma largura.
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen
import simbolo as S

FONTE = os.path.join(os.path.dirname(__file__), "../../assets/fonts/Poppins-{}.ttf")

def texto(txt, peso, x0, x1, base, cap):
    """Texto em curvas ocupando exatamente x0..x1 (o espaçamento entre letras se ajusta), com altura de maiúscula `cap`."""
    f = TTFont(FONTE.format(peso)); gs = f.getGlyphSet(); cmap = f.getBestCmap()
    esc = cap / f["OS/2"].sCapHeight
    nomes = [cmap[ord(c)] for c in txt]
    def borda(n):
        bp = BoundsPen(gs); gs[n].draw(bp); return bp.bounds
    esq = borda(nomes[0])[0] * esc
    dir_ = (gs[nomes[-1]].width - borda(nomes[-1])[2]) * esc
    larg = sum(gs[n].width for n in nomes) * esc - esq - dir_
    track = ((x1 - x0) - larg) / (len(nomes) - 1)
    pen, x = SVGPathPen(gs), x0 - esq
    for n in nomes:
        gs[n].draw(TransformPen(pen, (esc, 0, 0, -esc, x, base)))
        x += gs[n].width * esc + track
    return pen.getCommands()

def svg(vb, corpo):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}" role="img" aria-label="Lone Academy">{corpo}</svg>'

def horizontal(cor_a, cor_cap, cor_lone, cor_academy):
    # medidas do manual, nas unidades do símbolo (altura 419,5)
    lone = texto("LONE", "Bold", 456.5, 965.5, 210.5, 142.5)
    acad = texto("ACADEMY", "Medium", 446.5, 974.5, 301.5, 50.5)
    p = 24
    return svg(f"{-p} {-p} {974.5 + 2*p} {S.H + 2*p}",
               S.g(cor_a, cor_cap) + f'<path d="{lone}" fill="{cor_lone}"/><path d="{acad}" fill="{cor_academy}"/>')

def vertical(cor_a, cor_cap, cor_lone, cor_academy):
    largura = 528.0; k = 1.15
    sx = (largura - S.W * k) / 2
    y_lone = S.H * k + 64 + 142.5
    lone = texto("LONE", "Bold", 0, largura, y_lone, 142.5)
    acad = texto("ACADEMY", "Medium", 0, largura, y_lone + 91, 50.5)
    p = 24
    return svg(f"{-p} {-p} {largura + 2*p} {y_lone + 91 + 2*p}",
               S.g(cor_a, cor_cap, sx, 0, k) + f'<path d="{lone}" fill="{cor_lone}"/><path d="{acad}" fill="{cor_academy}"/>')

ARQUIVOS = {
    "assinatura-horizontal": horizontal(S.NOITE, S.AZUL, S.NOITE, S.AZUL),
    "assinatura-horizontal-negativa": horizontal(S.BRANCO, S.AZUL, S.BRANCO, S.CLARO),
    "assinatura-horizontal-azul": horizontal(S.BRANCO, S.NOITE, S.BRANCO, S.BRANCO),
    "assinatura-vertical": vertical(S.NOITE, S.AZUL, S.NOITE, S.AZUL),
    "assinatura-vertical-negativa": vertical(S.BRANCO, S.AZUL, S.BRANCO, S.CLARO),
}

if __name__ == "__main__":
    out = sys.argv[1]; os.makedirs(out, exist_ok=True)
    for k, v in ARQUIVOS.items():
        open(f"{out}/{k}.svg", "w").write(v)
    print("ok", list(ARQUIVOS))

def gerar_ts(destino):
    """Paths para a interface e o PDF (components/marca-paths.ts). Rodar de novo se a geometria mudar."""
    lone = texto("LONE", "Bold", 456.5, 965.5, 210.5, 142.5)
    acad = texto("ACADEMY", "Medium", 446.5, 974.5, 301.5, 50.5)
    open(destino, "w").write(
        "// GERADO por scripts/marca/assinatura.py (gerar_ts) — não editar à mão.\n"
        "// Marca Lone Academy v3: A + capelo (símbolo) e LONE/ACADEMY em Poppins, em curvas.\n"
        f"export const SIMBOLO_W = {S.f(S.W)};\nexport const SIMBOLO_H = {S.f(S.H)};\n"
        "/** Assinatura horizontal: largura total (o texto termina em 974,5) com a mesma altura do símbolo. */\n"
        "export const ASSINATURA_W = 974.5;\n"
        f'export const P_A = "{S.P_A}";\n'
        f'export const P_CAPELO = "{S.P_CAPELO}";\n'
        f'export const P_LONE = "{lone}";\n'
        f'export const P_ACADEMY = "{acad}";\n')

if __name__ == "__main__" and len(sys.argv) > 2 and sys.argv[2] == "--ts":
    gerar_ts(os.path.join(os.path.dirname(__file__), "../../components/marca-paths.ts"))
    print("components/marca-paths.ts ok")
