import "server-only";
import { Document, Page, View, Text, Image, StyleSheet, Svg, Polygon, Defs, LinearGradient, Stop, Circle, renderToBuffer } from "@react-pdf/renderer";
import QRCode from "qrcode";
import { cargaHoraria, dataCompleta } from "./format";
import { AssinaturaPdf, COR, SimboloPdf, registrarFontes } from "./pdf-marca";

export interface DadosCertificado {
  code: string; learner_name: string; company_name: string; course_title: string;
  workload_minutes: number | null; final_score: number | null; issued_at: string; competencies?: string[] | null;
}

// A4 deitado = 842 x 595 pt. Identidade Lone Academy: branco + faixa diagonal azul profundo → elétrico.
const W = 842, H = 595;
const s = StyleSheet.create({
  page: { backgroundColor: "#FFFFFF", fontFamily: "Poppins", color: COR.texto, position: "relative" },
  corpo: { position: "absolute", left: 56, top: 50, width: 430, bottom: 46 },
  kick: { marginTop: 40, fontSize: 9.5, fontWeight: 800, letterSpacing: 2.6, color: COR.eletrico },
  titulo: { marginTop: 8, fontSize: 26, fontWeight: 800, letterSpacing: -0.8, lineHeight: 1.1 },
  lead: { marginTop: 24, fontSize: 11, color: COR.apagado },
  nome: { marginTop: 4, fontSize: 30, fontWeight: 800, letterSpacing: -0.9, paddingBottom: 10, borderBottomWidth: 2, borderBottomColor: COR.eletrico, alignSelf: "flex-start" },
  texto: { marginTop: 16, fontSize: 11.5, lineHeight: 1.6, color: "#2C3346" },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 14 },
  chip: { fontSize: 8.5, fontWeight: 700, color: COR.profundo, backgroundColor: COR.suave, paddingVertical: 4, paddingHorizontal: 9, borderRadius: 10 },
  rodape: { position: "absolute", left: 0, bottom: 0, flexDirection: "row", gap: 24 },
  rotulo: { fontSize: 8, color: COR.apagado, letterSpacing: 0.4 },
  valor: { fontSize: 11, fontWeight: 700, marginTop: 3 },
  qrCaixa: { position: "absolute", right: 40, bottom: 40, width: 128, alignItems: "center", backgroundColor: "#FFFFFF", borderRadius: 12, padding: 10 },
  qrTexto: { fontSize: 6.8, color: COR.apagado, textAlign: "center", marginTop: 6, lineHeight: 1.35 },
  selo: { position: "absolute", right: 50, top: 80, width: 120, height: 120, alignItems: "center", justifyContent: "center" },
});

export async function pdfDoCertificado(c: DadosCertificado, appUrl: string): Promise<Buffer> {
  registrarFontes();
  const url = `${appUrl}/verificar/${c.code}`;
  const qr = await QRCode.toDataURL(url, { margin: 0, width: 260, color: { dark: COR.preto, light: "#FFFFFF" } });
  const nota = c.final_score != null ? ` e aproveitamento de ${c.final_score}% na avaliação final` : "";
  const doc = (
    <Document title={`Certificado - ${c.course_title}`} author="Lone Mídia" creator="Lone Academy">
      <Page size="A4" orientation="landscape" style={s.page}>
        {/* faixa diagonal da marca (direita) */}
        <Svg width={W} height={H} style={{ position: "absolute", left: 0, top: 0 }}>
          <Defs>
            <LinearGradient id="faixa" x1="0" y1="0" x2="1" y2="1">
              <Stop offset="0" stopColor={COR.preto} /><Stop offset="0.55" stopColor={COR.profundo} /><Stop offset="1" stopColor={COR.eletrico} />
            </LinearGradient>
            <LinearGradient id="fio" x1="0" y1="0" x2="1" y2="0">
              <Stop offset="0" stopColor={COR.eletrico} stopOpacity={0} /><Stop offset="1" stopColor={COR.eletrico} />
            </LinearGradient>
          </Defs>
          <Polygon points={`${W - 210},0 ${W},0 ${W},${H} ${W - 330},${H}`} fill="url(#faixa)" />
          <Polygon points={`${W - 232},0 ${W - 221},0 ${W - 341},${H} ${W - 352},${H}`} fill={COR.eletrico} />
          <Circle cx={W - 110} cy={140} r={54} fill="#FFFFFF" />
          <Circle cx={W - 110} cy={140} r={48} fill="none" stroke={COR.eletrico} strokeWidth={1.4} />
        </Svg>
        <View style={s.selo}><SimboloPdf largura={46} /></View>

        <View style={s.corpo}>
          <AssinaturaPdf altura={30} />
          <Text style={s.kick}>CERTIFICADO DE CONCLUSÃO</Text>
          <Text style={s.titulo}>{c.course_title}</Text>
          <Text style={s.lead}>Certificamos que</Text>
          <Text style={s.nome}>{c.learner_name}</Text>
          <Text style={s.texto}>
            concluiu o curso livre {c.course_title}, com carga horária de {cargaHoraria(c.workload_minutes)}{nota}, como integrante da equipe da {c.company_name}.
          </Text>
          {c.competencies?.length ? (
            <View style={s.chips}>
              <Text style={[s.rotulo, { width: "100%", marginBottom: 1 }]}>COMPETÊNCIAS AVALIADAS</Text>
              {c.competencies.map((k) => <Text key={k} style={s.chip}>{k}</Text>)}
            </View>
          ) : null}
          <View style={[s.rodape, { bottom: 18 }]}>
            <View><Text style={s.rotulo}>EMITIDO EM</Text><Text style={s.valor}>{dataCompleta(c.issued_at)}</Text></View>
            <View><Text style={s.rotulo}>CARGA HORÁRIA</Text><Text style={s.valor}>{cargaHoraria(c.workload_minutes)}</Text></View>
            <View><Text style={s.rotulo}>CÓDIGO DE VERIFICAÇÃO</Text><Text style={[s.valor, { letterSpacing: 0.8 }]}>{c.code}</Text></View>
            
          </View>
        </View>
        <Text style={{ position: "absolute", left: 56, bottom: 22, fontSize: 7.5, color: COR.apagado }}>
          Lone Academy · uma plataforma Lone Mídia · verifique em {appUrl.replace(/^https?:\/\//, "")}/verificar/{c.code}
        </Text>

        <View style={s.qrCaixa}>
          <Image src={qr} style={{ width: 92, height: 92 }} />
          <Text style={s.qrTexto}>Aponte a câmera para{"\n"}conferir a autenticidade</Text>
        </View>
      </Page>
    </Document>
  );
  return renderToBuffer(doc);
}
