import "server-only";
import { Document, Page, View, Text, StyleSheet, renderToBuffer } from "@react-pdf/renderer";
import type { Relatorio } from "./relatorio";
import { AssinaturaPdf, registrarFontes } from "./pdf-marca";

// PDF impresso: cor literal permitida (exceção do design system). Paleta da Lone Academy.
const C = {
  ink: "#050A24", muted: "#596075", line: "#E3E7EF", soft: "#F5F7FB", blue: "#0D4AF5", blueSoft: "#EEF2FF",
  dark: "#050A24", ok: "#16A34A", warn: "#D97706", bad: "#DC2626", s2: "#0891B2",
};
const MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
const MES_CURTO = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];

const s = StyleSheet.create({
  page: { fontFamily: "Poppins", fontSize: 9.5, color: C.ink, paddingTop: 0, paddingBottom: 40, backgroundColor: "#FFFFFF" },
  topo: { backgroundColor: C.dark, paddingVertical: 22, paddingHorizontal: 36, flexDirection: "row", alignItems: "center", gap: 12 },
  marca: { width: 30, height: 30, borderRadius: 7, backgroundColor: C.blue, alignItems: "center", justifyContent: "center" },
  marcaL: { color: "#FFFFFF", fontFamily: "Poppins", fontWeight: 700 as const, fontSize: 15 },
  topoT: { color: "#FFFFFF", fontFamily: "Poppins", fontWeight: 700 as const, fontSize: 13 },
  topoS: { color: "#C5C9D3", fontSize: 9, marginTop: 2 },
  corpo: { paddingHorizontal: 36, paddingTop: 22 },
  eyebrow: { color: C.blue, fontSize: 8, letterSpacing: 1.6, fontFamily: "Poppins", fontWeight: 700 as const },
  titulo: { fontSize: 20, fontFamily: "Poppins", fontWeight: 700 as const, marginTop: 4 },
  kpis: { flexDirection: "row", gap: 10, marginTop: 16 },
  kpi: { flex: 1, borderWidth: 1, borderColor: C.line, borderRadius: 8, padding: 10 },
  kpiL: { color: C.muted, fontSize: 7.5, letterSpacing: 0.8 },
  kpiV: { fontSize: 20, fontFamily: "Poppins", fontWeight: 700 as const, marginTop: 4 },
  kpiH: { color: C.muted, fontSize: 8, marginTop: 2 },
  secao: { marginTop: 18 },
  h2: { fontSize: 11.5, fontFamily: "Poppins", fontWeight: 700 as const, marginBottom: 8 },
  caixa: { backgroundColor: C.blueSoft, borderRadius: 8, padding: 10, fontSize: 10, lineHeight: 1.45 },
  compLinha: { flexDirection: "row", alignItems: "center", marginBottom: 6 },
  compNome: { width: 150 },
  trilho: { flex: 1, height: 6, backgroundColor: C.soft, borderRadius: 3 },
  compPct: { width: 40, textAlign: "right", fontFamily: "Poppins", fontWeight: 700 as const },
  tabela: { borderWidth: 1, borderColor: C.line, borderRadius: 6 },
  tr: { flexDirection: "row", borderBottomWidth: 1, borderBottomColor: C.line, paddingVertical: 5, paddingHorizontal: 8 },
  th: { color: C.muted, fontSize: 7.5, fontFamily: "Poppins", fontWeight: 700 as const },
  rodape: { position: "absolute", bottom: 18, left: 36, right: 36, flexDirection: "row", justifyContent: "space-between", color: C.muted, fontSize: 7.5 },
});

const corPct = (p: number) => (p >= 80 ? C.ok : p >= 60 ? C.warn : C.bad);

export async function pdfDoRelatorio(r: Relatorio): Promise<Buffer> {
  registrarFontes();
  const mes = `${MESES[r.geradoEm.getMonth()]} de ${r.geradoEm.getFullYear()}`;
  const atencao = r.linhas.filter((l) => ["Parado", "Atrasado", "Não começou"].includes(l.situacao)).slice(0, 8);
  const destaques = r.linhas.filter((l) => l.skill != null).slice(0, 3);
  const cols: [string, number][] = [["Pessoa", 3], ["Equipe", 1.6], ["Situação", 1.3], ["Skill", 0.8], ["Adoção", 0.8], ["Cursos", 0.8], ["Precisa melhorar", 2.4]];

  const doc = (
    <Document title={`Relatório Lone Academy - ${r.empresa} - ${mes}`} author="Lone Mídia">
      <Page size="A4" style={s.page}>
        <View style={s.topo} fixed>
          <AssinaturaPdf altura={26} negativo />
          <View style={{ marginLeft: "auto", alignItems: "flex-end" }}><Text style={s.topoT}>Relatório mensal do time</Text><Text style={s.topoS}>{mes}</Text></View>
        </View>
        <View style={s.corpo}>
          <Text style={s.eyebrow}>EMPRESA</Text>
          <Text style={s.titulo}>{r.empresa}</Text>

          <View style={s.kpis}>
            <Kpi l="SKILL DO TIME" v={r.skill ?? "—"} h={r.skill == null ? "sem provas ainda" : "0 a 100, pelas provas"} />
            <Kpi l="ÍNDICE DE ADOÇÃO" v={r.adocao} h={`${r.ativos14} de ${r.pessoas} estudaram em 14 dias`} />
            <Kpi l="ASSENTOS EM USO" v={`${r.ativos}/${r.assentos}`} h={`${Math.max(0, r.assentos - r.ativos)} livres`} />
            <Kpi l="CERTIFICADOS NO MÊS" v={r.certificadosMes} h="emitidos neste mês" />
          </View>

          <View style={s.secao}>
            <Text style={s.h2}>Diagnóstico</Text>
            <Text style={s.caixa}>{r.diagnostico ?? "O diagnóstico aparece quando o time responder as primeiras provas e perguntas das aulas."}</Text>
          </View>

          {r.competencias.length > 0 && (
            <View style={s.secao}>
              <Text style={s.h2}>Acerto por competência</Text>
              {r.competencias.map((c) => (
                <View key={c.id} style={s.compLinha}>
                  <Text style={s.compNome}>{c.nome}</Text>
                  <View style={s.trilho}><View style={{ width: `${c.pct}%`, height: 6, borderRadius: 3, backgroundColor: c.suficiente ? corPct(c.pct) : C.line }} /></View>
                  <Text style={[s.compPct, { color: c.suficiente ? corPct(c.pct) : C.muted }]}>{c.suficiente ? `${c.pct}%` : "—"}</Text>
                </View>
              ))}
              <Text style={{ color: C.muted, fontSize: 7.5, marginTop: 2 }}>Abaixo de 80% = precisa melhorar. "—" = poucas respostas ainda.</Text>
            </View>
          )}

          {r.historico.length > 0 && (
            <View style={s.secao}>
              <Text style={s.h2}>Evolução (média do time)</Text>
              <View style={[s.tabela, { flexDirection: "row" }]}>
                {r.historico.map((p, i) => (
                  <View key={p.mes} style={{ flex: 1, padding: 8, borderLeftWidth: i ? 1 : 0, borderLeftColor: C.line }}>
                    <Text style={s.th}>{MES_CURTO[Number(p.mes.slice(5, 7)) - 1]}/{p.mes.slice(2, 4)}</Text>
                    <Text style={{ marginTop: 4, color: C.blue, fontFamily: "Poppins", fontWeight: 700 as const }}>Skill {p.skill ?? "—"}</Text>
                    <Text style={{ marginTop: 2, color: C.s2, fontFamily: "Poppins", fontWeight: 700 as const }}>Adoção {p.adocao}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          <View style={[s.secao, { flexDirection: "row", gap: 14 }]} wrap={false}>
            <View style={{ flex: 1 }}>
              <Text style={s.h2}>Destaques</Text>
              {destaques.length ? destaques.map((l, i) => <Text key={l.nome} style={{ marginBottom: 4 }}>{i + 1}º {l.nome} — skill {l.skill} ({l.nivel})</Text>)
                : <Text style={{ color: C.muted }}>Aparecem depois das primeiras provas.</Text>}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.h2}>Precisa de atenção</Text>
              {atencao.length ? atencao.map((l) => <Text key={l.nome} style={{ marginBottom: 4 }}>{l.nome} — {l.situacao.toLowerCase()}</Text>)
                : <Text style={{ color: C.muted }}>Ninguém parado ou atrasado.</Text>}
            </View>
          </View>

          <View style={s.secao}>
            <Text style={s.h2}>Time ({r.linhas.length} pessoas)</Text>
            <View style={s.tabela}>
              <View style={[s.tr, { backgroundColor: C.soft }]} fixed>
                {cols.map(([c, f]) => <Text key={c} style={[s.th, { flex: f }]}>{c.toUpperCase()}</Text>)}
              </View>
              {r.linhas.map((l) => (
                <View key={l.nome + l.cargo} style={s.tr} wrap={false}>
                  <Text style={{ flex: 3 }}>{l.nome}{l.cargo ? <Text style={{ color: C.muted }}> · {l.cargo}</Text> : null}</Text>
                  <Text style={{ flex: 1.6, color: C.muted }}>{l.equipe || "—"}</Text>
                  <Text style={{ flex: 1.3 }}>{l.situacao}</Text>
                  <Text style={{ flex: 0.8, fontFamily: "Poppins", fontWeight: 700 as const }}>{l.skill ?? "—"}</Text>
                  <Text style={{ flex: 0.8 }}>{l.adocao}</Text>
                  <Text style={{ flex: 0.8 }}>{l.concluidos}</Text>
                  <Text style={{ flex: 2.4, color: C.muted }}>{l.melhorar || "—"}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>
        <View style={s.rodape} fixed>
          <Text>Lone Academy · uma plataforma Lone Mídia · gerado em {r.geradoEm.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" })}</Text>
          <Text render={({ pageNumber, totalPages }) => `${pageNumber} / ${totalPages}`} />
        </View>
      </Page>
    </Document>
  );
  return renderToBuffer(doc);
}

function Kpi({ l, v, h }: { l: string; v: string | number; h: string }) {
  return (
    <View style={s.kpi}>
      <Text style={s.kpiL}>{l}</Text>
      <Text style={s.kpiV}>{String(v)}</Text>
      <Text style={s.kpiH}>{h}</Text>
    </View>
  );
}
