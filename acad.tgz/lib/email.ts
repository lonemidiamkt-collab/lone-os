// Envio de e-mail da Lone Academy (Resend, mesma conta do Lone OS). Só servidor.
// Sem RESEND_API_KEY (dev/teste) não envia: devolve o motivo para a tela mostrar o link e a pessoa mandar por outro canal.
import "server-only";

export interface Email { para: string; nome?: string; assunto: string; html: string; texto: string }
export type ResultadoEmail = { enviado: true; id?: string } | { enviado: false; motivo: string };

const REMETENTE = () => process.env.EMAIL_FROM || "Lone Academy <academy@lonemidia.com>";

export async function enviarEmail(e: Email): Promise<ResultadoEmail> {
  const chave = process.env.RESEND_API_KEY;
  if (!chave) {
    console.info("[email] RESEND_API_KEY vazio: e-mail não enviado →", e.para, "|", e.assunto);
    return { enviado: false, motivo: "envio de e-mail desligado neste ambiente (falta RESEND_API_KEY)" };
  }
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${chave}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: REMETENTE(), ...(process.env.EMAIL_REPLY_TO ? { reply_to: process.env.EMAIL_REPLY_TO } : {}), to: [e.nome ? `${e.nome.replace(/[<>"]/g, "")} <${e.para}>` : e.para], subject: e.assunto, html: e.html, text: e.texto }),
      signal: AbortSignal.timeout(10_000),
    });
    const corpo = (await r.json().catch(() => ({}))) as { id?: string; message?: string };
    if (!r.ok) return { enviado: false, motivo: `o serviço de e-mail recusou (${corpo.message ?? r.status})` };
    return { enviado: true, id: corpo.id };
  } catch (err) {
    console.error("[email] falhou:", err);
    return { enviado: false, motivo: "o serviço de e-mail não respondeu" };
  }
}

const esc = (t: string) => t.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

/** E-mail "Seu acesso à Lone Academy": link de primeiro acesso do dono da empresa. Tabelas e estilo inline (Gmail/Outlook). */
export function emailDeAcesso(o: { nome: string; empresa: string; email: string; link: string; appUrl: string; validadeDias: number }): Email {
  const primeiro = o.nome.trim().split(/\s+/)[0];
  const app = o.appUrl.replace(/\/$/, "");
  const passos = [
    ["Crie sua senha", "Clique no botão e escolha a senha. Você entra com este e-mail."],
    ["Convide o time", "Mande o link no WhatsApp ou crie o acesso de cada pessoa na hora."],
    ["Atribua o primeiro curso", "Escolha o curso e um prazo. O painel mostra quem começou e quem parou."],
  ];
  const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Seu acesso à Lone Academy</title></head>
<body style="margin:0;padding:0;background:#F5F7FB;font-family:Poppins,Segoe UI,Helvetica,Arial,sans-serif;color:#050A24;">
<span style="display:none;max-height:0;overflow:hidden;">${esc(o.empresa)} já pode treinar o time. Crie sua senha em 1 minuto.</span>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F5F7FB;padding:32px 12px;"><tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#FFFFFF;border-radius:20px;overflow:hidden;">
  <tr><td style="background:#050A24;background-image:linear-gradient(135deg,#102585,#050A24);padding:28px 32px;">
    <img src="${app}/brand/email-assinatura-negativa.png" width="105" height="48" alt="Lone Academy" style="display:block;border:0;">
  </td></tr>
  <tr><td style="padding:32px 32px 8px;">
    <p style="margin:0 0 6px;font-size:12px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:#0D4AF5;">Acesso liberado</p>
    <h1 style="margin:0 0 12px;font-size:26px;line-height:1.2;font-weight:800;letter-spacing:-.02em;">Oi, ${esc(primeiro)}! A Lone Academy da ${esc(o.empresa)} está pronta.</h1>
    <p style="margin:0 0 24px;font-size:15px;line-height:1.6;color:#4A5372;">É a plataforma de treinamento da Lone Mídia para o seu time: aulas curtas sobre atendimento e vendas, prova no fim de cada módulo e certificado. Você acompanha tudo num painel.</p>
    <table role="presentation" cellpadding="0" cellspacing="0"><tr><td style="border-radius:14px;background:#0D4AF5;">
      <a href="${esc(o.link)}" style="display:inline-block;padding:15px 28px;font-size:15px;font-weight:700;color:#FFFFFF;text-decoration:none;border-radius:14px;">Criar minha senha</a>
    </td></tr></table>
    <p style="margin:14px 0 0;font-size:13px;color:#6B7390;">O link vale ${o.validadeDias} dias e funciona uma vez. Seu login é <strong style="color:#050A24;">${esc(o.email)}</strong>.</p>
  </td></tr>
  <tr><td style="padding:24px 32px 8px;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #E6E9F2;">
      ${passos.map(([t, d], i) => `<tr><td valign="top" width="40" style="padding:16px 0 0;"><div style="width:28px;height:28px;border-radius:9px;background:#EEF2FF;color:#0D4AF5;font-weight:800;font-size:13px;line-height:28px;text-align:center;">${i + 1}</div></td>
      <td style="padding:16px 0 0;"><p style="margin:0;font-size:15px;font-weight:700;">${t}</p><p style="margin:2px 0 0;font-size:14px;line-height:1.5;color:#4A5372;">${d}</p></td></tr>`).join("")}
    </table>
  </td></tr>
  <tr><td style="padding:24px 32px 32px;">
    <p style="margin:0;font-size:13px;line-height:1.6;color:#6B7390;">Se o botão não abrir, copie este endereço no navegador:<br><a href="${esc(o.link)}" style="color:#0D4AF5;word-break:break-all;">${esc(o.link)}</a></p>
    <p style="margin:16px 0 0;font-size:13px;line-height:1.6;color:#6B7390;">Dúvida? Responda este e-mail ou chame a Lone Mídia no WhatsApp de sempre.</p>
  </td></tr>
</table>
<p style="margin:16px 0 0;font-size:12px;color:#8A91A8;">Lone Academy · uma plataforma Lone Mídia</p>
</td></tr></table></body></html>`;
  const texto = `Oi, ${primeiro}! A Lone Academy da ${o.empresa} está pronta.

É a plataforma de treinamento da Lone Mídia para o seu time: aulas curtas, prova no fim de cada módulo e certificado.

Crie sua senha (o link vale ${o.validadeDias} dias e funciona uma vez):
${o.link}

Seu login é ${o.email}.

1. Crie sua senha
2. Convide o time
3. Atribua o primeiro curso

Dúvida? Responda este e-mail ou chame a Lone Mídia no WhatsApp.
Lone Academy · uma plataforma Lone Mídia`;
  return { para: o.email, nome: o.nome, assunto: `Seu acesso à Lone Academy chegou, ${primeiro}`, html, texto };
}
