import "server-only";
import path from "node:path";
import { Font, Svg, Path } from "@react-pdf/renderer";
import { ASSINATURA_W, P_A, P_ACADEMY, P_CAPELO, P_LONE, SIMBOLO_H, SIMBOLO_W } from "@/components/marca-paths";

// Marca da Lone Academy nos PDFs (certificado e relatório). Cor literal permitida: documento impresso.
// Paleta v3: azul #0D4AF5 (o mesmo da Lone Mídia), azul-noite #050A24, azul claro #6F8EFF.
export const COR = {
  preto: "#050A24", profundo: "#102585", eletrico: "#0D4AF5", neutro: "#F5F7FB", claro: "#6F8EFF",
  texto: "#050A24", apagado: "#596075", linha: "#E3E7EF", suave: "#EEF2FF",
};

let registrada = false;
/** Poppins (OFL) em assets/fonts. O next.config inclui a pasta no standalone das rotas de PDF. */
export function registrarFontes() {
  if (registrada) return;
  const dir = path.join(process.cwd(), "assets", "fonts");
  Font.register({
    family: "Poppins",
    fonts: [
      { src: path.join(dir, "Poppins-Regular.ttf"), fontWeight: 400 },
      { src: path.join(dir, "Poppins-Medium.ttf"), fontWeight: 500 },
      { src: path.join(dir, "Poppins-Bold.ttf"), fontWeight: 700 },
      { src: path.join(dir, "Poppins-Bold.ttf"), fontWeight: 800 },
    ],
  });
  Font.registerHyphenationCallback((w) => [w]);
  registrada = true;
}

/** Símbolo (A + capelo). `negativo` = fundo escuro. */
export function SimboloPdf({ largura, negativo }: { largura: number; negativo?: boolean }) {
  return (
    <Svg width={largura} height={largura * SIMBOLO_H / SIMBOLO_W} viewBox={`0 0 ${SIMBOLO_W} ${SIMBOLO_H}`}>
      <Path d={P_A} fill={negativo ? "#FFFFFF" : COR.preto} />
      <Path d={P_CAPELO} fill={COR.eletrico} />
    </Svg>
  );
}

/** Assinatura horizontal (símbolo + LONE / ACADEMY em curvas). `altura` ≈ altura do símbolo em pt. */
export function AssinaturaPdf({ altura = 26, negativo }: { altura?: number; negativo?: boolean }) {
  const h = altura * 1.25;
  return (
    <Svg width={h * ASSINATURA_W / SIMBOLO_H} height={h} viewBox={`0 0 ${ASSINATURA_W} ${SIMBOLO_H}`}>
      <Path d={P_A} fill={negativo ? "#FFFFFF" : COR.preto} />
      <Path d={P_CAPELO} fill={COR.eletrico} />
      <Path d={P_LONE} fill={negativo ? "#FFFFFF" : COR.preto} />
      <Path d={P_ACADEMY} fill={negativo ? COR.claro : COR.eletrico} />
    </Svg>
  );
}
